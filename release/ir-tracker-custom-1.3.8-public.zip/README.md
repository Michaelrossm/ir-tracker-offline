# IR Tracker Offline — 1.3.8

**Deutsch** | [English](#english)

Lokale, cloudfreie Firmware für einen **ESP32-C3-basierten IR-Stromzähler-Tracker**. SML- und OBIS-Daten werden direkt auf dem Gerät ausgewertet – ohne Cloud-Zwang und ohne externen Server.

Erstellt und gepflegt von **Michael Roßmann**.

> Unabhängiges Community-Projekt. Nicht mit Solakon verbunden und nicht von Solakon unterstützt. Solakon ist eine Marke ihrer jeweiligen Inhaber.

## Warum IR Tracker Offline?

Der Tracker soll Messwerte nicht nur anzeigen, sondern sie möglichst einfach für bestehende lokale Systeme bereitstellen. Deshalb stehen mehrere Schnittstellen parallel zur Verfügung.

Besonders praktisch sind die **Shelly- und EcoTracker-Kompatibilität**: Der Tracker stellt nur lesende Shelly-EM-, Shelly-Pro-EM- und EcoTracker-kompatible Endpunkte bereit. Systeme, die entsprechende Energiemessgeräte abfragen können, können dadurch unter Umständen ohne eine speziell für den IR Tracker entwickelte Integration auf die Messwerte zugreifen.

Zusätzlich stehen **Home Assistant MQTT Discovery, JSON/HTTP, CSV, Prometheus/OpenMetrics und Influx Line Protocol** zur Verfügung. Die komplette SML-/OBIS-Auswertung findet lokal auf dem ESP32-C3 statt.

> **Wichtig:** Shelly- und EcoTracker-Kompatibilität bezeichnet ausschließlich kompatibles lokales API- und Netzwerkverhalten. Der IR Tracker gibt sich niemals als Originalgerät eines Fremdherstellers aus: Modell `IRTRACKER-C3`, API-Modell `IRTRACKER-C3-3EM`, Seriennummer `IRT-XXXXXX`, Hostname `irtracker-XXXXXX` und die echte ESP32-MAC bleiben eindeutig neutral. Systeme, die zwingend eine fremde Produktkennung oder Cloud-Bindung verlangen, werden bewusst nicht durch Identitätsfälschung unterstützt.

## Funktionen

- **vollständig lokale SML-/OBIS- sowie IEC-62056-21/D0-Auswertung** ohne Cloud-Abhängigkeit
- Livewerte für Gesamtleistung, Netzbezug, Einspeisung sowie verfügbare L1/L2/L3-Werte
- **Shelly-EM- und Shelly-Pro-EM-kompatible Leseendpunkte** für eine möglichst einfache Einbindung in bestehende Systeme
- **EcoTracker-kompatible lokale API** unter `/v1/json` einschließlich Messwertalter
- **Neutrale Integrations-API** unter `/api/v1/meter`, dasselbe stabile Schema unter MQTT `irtracker/<id>/meter` und optionales read-only Modbus TCP
- neutrale mDNS-Erkennung über `_shelly._tcp` und `_everhome._tcp`; der standardmäßig ausgeschaltete Speicher-Kompatibilitätsmodus öffnet nur die zugehörigen lokalen Leseendpunkte
- **Home Assistant über MQTT Discovery**
- lokale Schnittstellen über **JSON/HTTP, CSV, Prometheus/OpenMetrics und Influx Line Protocol**
- lokale Historie mit Stunde, Tag, Woche, Monat, Jahr und Langzeitansicht
- Spannungs- und Stromwerte nur im RAM, nicht in der Historie
- interaktive Diagramme für Maus und Touch
- bis zu drei WLANs; automatischer zeitbegrenzter Setup-Hotspot als Rückfall
- eine Universal-Firmware für WLAN und optionales W5500-LAN; LAN wird bei
  vorhandenem Link bevorzugt, WLAN bleibt als automatischer Rückfall verbunden
- signierte manuelle WLAN-Updates sowie sichere GitHub-Prüfung mit optionaler automatischer Installation
- vollständige signierte Ein-Datei-Updates (`.irup`) für Firmware und Weboberfläche
- Einstellungs-/Historienbackup, Selbsttest und Diagnose
- geschützte GPIO-/Baudraten-Diagnose zur Unterstützung unterschiedlicher Hardware
- browserlokale Farbauswahl und Sprache Deutsch/Englisch
- Eco-Modus, adaptiver WLAN-Sendepegel und automatische Leistungs-Boosts für
  Verbindungsaufbau, Updates, Exporte und Prüfungen
- automatische UART-/Parser-Wiederherstellung bei ausbleibenden Zählerdaten
- gesonderter Werksprüfungs-Build mit PASS/FAIL-Prüfung für die eigene LAN-/PoE-Platine
- Produktions-Build ausschließlich mit lesenden Speicher-/Smart-Home-Schnittstellen
- alle acht aktuellen statischen Webassets in einem manifest- und SHA-256-geprüften
  64-kB-Container; kompakte Recovery-Oberfläche bei fehlenden Assets

## Schnittstellen und Integration

| Schnittstelle | Verwendung |
| --- | --- |
| Shelly-kompatible Endpunkte | Einbindung in Systeme, die Shelly EM / Pro EM abfragen können |
| EcoTracker-kompatible API | Einbindung über das lokale EcoTracker-Format `/v1/json` |
| MQTT Discovery | automatische Sensoren in Home Assistant |
| JSON/HTTP | eigene Integrationen, Automatisierung und lokale Abfragen |
| CSV | einfache Weiterverarbeitung aktueller Werte |
| Prometheus / OpenMetrics | Monitoring und Zeitreihen-Erfassung |
| Influx Line Protocol | Übergabe an Influx-kompatible Systeme |

Der Tracker arbeitet dabei ausschließlich als **lesender Stromzähler**. Regelungen wie Nulleinspeisung, Ladegrenzen oder Zeitpläne gehören weiterhin in Speicher, Wechselrichter, Wallbox oder das jeweilige Automatisierungssystem.

Die konkreten URLs und API-Endpunkte stehen in [INTERFACES.md](docs/INTERFACES.md).

## Unterstützte Messwerte und Stromzähler

Welche Werte verfügbar sind, hängt vom angeschlossenen Stromzähler und dessen freigeschalteten OBIS-Daten ab. L1/L2/L3, Spannung oder Strom können nur ausgegeben werden, wenn der Zähler diese Werte tatsächlich über seine optische Schnittstelle überträgt.

Neben SML unterstützt die Firmware passive und aktive IEC-62056-21/D0-Zähler.
Die aktive Abfrage verwendet `/?!` und `ACK 000`. Für Hardware mit unbekannter
RX-Belegung steht eine geschützte GPIO-/Baudraten-Diagnose zur Verfügung; ein
Eingang wird erst nach einem frischen, gültigen Telegramm bestätigt.

Die aktuelle Übersicht steht unter [Kompatibilität](docs/compatibility/README.md).

## Erster Zugang – Standardpasswort

Nach einer frischen Installation startet der Tracker das WLAN `IR-Tracker-Setup-XXXX`.
Die vier Zeichen `XXXX` werden direkt aus diesem WLAN-Namen übernommen:

| Zugang | Benutzername | Passwort |
| --- | --- | --- |
| Setup-WLAN `IR-Tracker-Setup-XXXX` | – | `IRTracker-XXXX` |
| Weboberfläche | `admin` | `IRTracker-XXXX` |

Beispiel: Heißt das WLAN `IR-Tracker-Setup-F2A0`, lautet das Passwort `IRTracker-F2A0`. Groß-/Kleinschreibung und Bindestrich müssen exakt stimmen. Nach einer eigenen Passwortänderung gilt stattdessen das selbst gewählte Admin-Passwort.

## Sicherheit

Die Oberfläche verwendet HTTP und gehört ausschließlich in ein vertrauenswürdiges Heim- oder getrenntes IoT-Netz. **Keine Ports ins Internet freigeben.** Für Fernzugriff VPN verwenden. Details: [SECURITY.md](.github/SECURITY.md).

## Installation

Siehe [INSTALLATION.md](docs/INSTALLATION.md). Vor jedem Flashvorgang vollständige Gerätesicherung, Einstellungen und Historie sichern. Die persönliche Original-Firmware darf nicht öffentlich verteilt werden.

### Update auf 1.3.8 – richtige Reihenfolge

- **Tracker mit „Vollständiges Update (.irup)“:** Direkt
  `ir-tracker-update-1.3.8.irup` unter **Wartung** installieren. Firmware und
  Weboberfläche werden gemeinsam geprüft und aktualisiert.
- **Älterer Tracker, der nur `.irfw` anbietet:** Zuerst
  `ir-tracker-custom-1.3.8.irfw` installieren und den Neustart abwarten. Danach
  erneut **Wartung** öffnen und `ir-tracker-update-1.3.8.irup` installieren.
  Dieser zweite Schritt ergänzt die passende Weboberfläche.
- **Sehr alter Stand ohne signiertes WLAN-Update oder ohne kompatible
  64-kB-Partition:** Zuerst den aktuellen USB-Installer verwenden. Er sichert
  und prüft das Gerät, migriert ausschließlich den bisherigen 64-kB-
  `coredump`-Bereich zu `debugfs` und erhält NVS, Einstellungen und Historie.

Das einzelne Asset-Image ist nur für Diagnose und manuelle Wiederherstellung
gedacht. Für normale Updates ab 1.3.8 wird ausschließlich die `.irup` benötigt.

## Dokumentation

- [Installation und Rückkehr / Installation and recovery](docs/INSTALLATION.md)
- [Kompatibilität / Compatibility](docs/compatibility/README.md)
- [Sicherheit / Security](.github/SECURITY.md)
- [Schnittstellen / Interfaces](docs/INTERFACES.md)
- [USB-Umschaltung / USB switching](docs/USB_SWITCHING.md)
- [Hardwaretest / Hardware test](docs/HARDWARE_TEST.md)
- [Dauertest / Soak test](docs/SOAK_TEST.md)
- [Release-Prüfung / Release checklist](docs/RELEASE_CHECKLIST.md)
- [Rechteprüfung / Rights review](docs/legal/RIGHTS_REVIEW.md)
- [Markenhinweis / Trademarks](docs/legal/TRADEMARKS.md)
- [Hinweise zu Drittsoftware / Third-party notices](docs/legal/THIRD_PARTY_NOTICES.md)
- [Firmware-Architektur / Firmware architecture](docs/ARCHITECTURE.md)
- [Webasset-Partition / Web asset partition](docs/ASSET_PARTITION.md)

## Projektstatus

Version **1.3.8** akzeptiert beim signierten Firmwareupdate auch einen
vollständig geprüften älteren Asset-Container. Dadurch bleibt ein Gerät nach
einem normalen `.irfw`-Update bedienbar, auch wenn die separate 64-kB-
Asset-Partition erst später aktualisiert wird. Fehlende oder manipulierte
benötigte Dateien führen weiterhin sicher zur Recovery-Oberfläche. Die
Schnittstellenkonfiguration ist jetzt übersichtlich unter „Schnittstellen“
gebündelt; Partitionen, History und Messwertschnittstellen bleiben unverändert.
Rückmeldungen zu unterschiedlichen Stromzählern und lokalen Integrationen sind willkommen.

Neue USB-Installationen verwenden für den optionalen 64-kB-Debugspeicher das
Label `debugfs`. Dieselbe Firmware erkennt bei bestehenden OTA-Geräten
automatisch das frühere Label `coredump`; OTA-Slots, Offsets und Historie sind
unverändert. Für die reine Umbenennung ist daher kein USB-Neuflash nötig.

Die Universal-Firmware enthält bereits W5500-LAN mit WLAN-Fallback. Die
LAN-/PoE-Platine ist noch nicht auf echter Hardware validiert.

## Lizenz

Copyright © 2026 Michael Roßmann. Lizenz: PolyForm Noncommercial 1.0.0. Private und sonstige nichtkommerzielle Nutzung ist gemäß Lizenz erlaubt; gewerbliche Nutzung ist nicht gestattet. Verbindlich sind [LICENSE.md](LICENSE.md), der [Urheberhinweis](AUTHORS.md), die [Rechteprüfung](docs/legal/RIGHTS_REVIEW.md) und der [Markenhinweis](docs/legal/TRADEMARKS.md).

---

## English

Local, cloud-free firmware for an **ESP32-C3-based IR electricity meter tracker**. SML and OBIS data is processed directly on the device without requiring a cloud service or external server.

Created and maintained by **Michael Roßmann**.

> Independent community project. Not affiliated with or endorsed by Solakon. Solakon is a trademark of its respective owners.

### Why IR Tracker Offline?

The tracker is designed not only to display readings but also to expose them to existing local systems through several interfaces.

Particularly useful are **Shelly and EcoTracker compatibility**. The tracker provides read-only Shelly EM, Shelly Pro EM and EcoTracker compatible endpoints. Systems capable of reading corresponding energy meters may therefore be able to consume IR Tracker measurements without a dedicated IR Tracker integration.

It also provides **Home Assistant MQTT Discovery, JSON/HTTP, CSV, Prometheus/OpenMetrics and Influx Line Protocol**. SML/OBIS processing remains completely local on the ESP32-C3.

> **Note:** Shelly and EcoTracker compatibility refers exclusively to compatible local API and network behavior. IR Tracker never identifies itself as an original third-party device: model `IRTRACKER-C3`, API model `IRTRACKER-C3-3EM`, serial `IRT-XXXXXX`, hostname `irtracker-XXXXXX`, and the genuine ESP32 MAC remain neutral. Systems that require a third-party product identity or cloud binding are deliberately not supported through identity spoofing.

### Features

- **fully local SML/OBIS and IEC 62056-21/D0 processing** without cloud dependency
- live total power, grid import/export and available L1/L2/L3 readings
- **read-only Shelly EM and Shelly Pro EM compatible endpoints** for easier integration with existing systems
- **EcoTracker-compatible local API** at `/v1/json`, including reading age
- **Neutral integration API** at `/api/v1/meter`, the same stable schema at MQTT `irtracker/<id>/meter`, and optional read-only Modbus TCP
- neutral mDNS discovery through `_shelly._tcp` and `_everhome._tcp`; the storage compatibility mode is disabled by default and opens only the corresponding local read endpoints
- **Home Assistant MQTT Discovery**
- local **JSON/HTTP, CSV, Prometheus/OpenMetrics and Influx Line Protocol** interfaces
- local history for hour, day, week, month, year and long-term views
- voltage and current kept in RAM only, never in history
- interactive mouse and touch charts
- up to three Wi-Fi networks; automatic time-limited setup hotspot fallback
- one universal firmware for Wi-Fi and optional W5500 Ethernet; Ethernet is
  preferred while linked and Wi-Fi remains connected as automatic fallback
- signed manual Wi-Fi updates plus secure GitHub checks and optional automatic installation
- settings/history backup, guided self-test and diagnostics
- protected GPIO/baud-rate diagnostics for different hardware variants
- browser-local colors and German/English language selection
- Eco mode, adaptive Wi-Fi transmit power and automatic performance boosts for
  association, updates, exports and tests
- automatic UART/parser recovery when meter data stops
- separate factory-test build with PASS/FAIL checks for the custom LAN/PoE board
- production build contains read-only battery and smart-home interfaces only
- all eight current static web assets in a manifest- and SHA-256-verified 64-kB
  container, with a compact recovery UI if assets are unavailable

### Interfaces and integration

| Interface | Use |
| --- | --- |
| Shelly-compatible endpoints | integration with systems capable of reading Shelly EM / Pro EM |
| EcoTracker-compatible API | integration through the local EcoTracker `/v1/json` format |
| MQTT Discovery | automatic Home Assistant sensors |
| JSON/HTTP | custom integrations, automation and local queries |
| CSV | simple processing of current readings |
| Prometheus / OpenMetrics | monitoring and time-series collection |
| Influx Line Protocol | output to Influx-compatible systems |

The tracker operates exclusively as a **read-only electricity meter**. Zero-export control, charge limits and schedules remain the responsibility of the battery, inverter, wallbox or automation system.

See [INTERFACES.md](docs/INTERFACES.md) for the actual URLs and API endpoints.

### Supported readings and meters

Available readings depend on the connected electricity meter and the OBIS values it exposes. L1/L2/L3, voltage and current can only be provided when the meter actually transmits those values through its optical interface.

In addition to SML, the firmware supports passive and active IEC 62056-21/D0
meters. Active polling uses `/?!` and `ACK 000`. A protected GPIO/baud-rate
diagnostic is available for hardware with an unknown RX pin; an input is only
accepted after a fresh, valid telegram.

See the current [compatibility overview](docs/compatibility/README.md).

### First access – default password

After a fresh installation, the tracker starts the Wi-Fi network `IR-Tracker-Setup-XXXX`. Copy the four `XXXX` characters directly from that network name:

| Access | User name | Password |
| --- | --- | --- |
| Setup Wi-Fi `IR-Tracker-Setup-XXXX` | – | `IRTracker-XXXX` |
| Web interface | `admin` | `IRTracker-XXXX` |

Example: If the Wi-Fi network is named `IR-Tracker-Setup-F2A0`, the password is `IRTracker-F2A0`. Capitalization and the hyphen must match exactly. After setting a custom password, use that chosen administrator password instead.

### Security

The interface uses HTTP and must only be operated in a trusted home network or isolated IoT network. **Never expose its ports to the internet.** Use a VPN for remote access. See [SECURITY.md](.github/SECURITY.md).

### Installation

See [INSTALLATION.md](docs/INSTALLATION.md). Before flashing, back up the complete device, settings and history. The personal original firmware must never be distributed publicly.

### Documentation

- [Installation and recovery](docs/INSTALLATION.md)
- [Compatibility](docs/compatibility/README.md)
- [Security](.github/SECURITY.md)
- [Interfaces](docs/INTERFACES.md)
- [USB switching](docs/USB_SWITCHING.md)
- [Hardware test](docs/HARDWARE_TEST.md)
- [Soak test](docs/SOAK_TEST.md)
- [Release checklist](docs/RELEASE_CHECKLIST.md)
- [Rights review](docs/legal/RIGHTS_REVIEW.md)
- [Trademarks](docs/legal/TRADEMARKS.md)
- [Third-party notices](docs/legal/THIRD_PARTY_NOTICES.md)
- [Firmware architecture](docs/ARCHITECTURE.md)
- [Web asset partition](docs/ASSET_PARTITION.md)

### Project status

Version **1.3.8** accepts a fully verified older asset container during a
signed firmware update. The tracker therefore remains usable after a normal
`.irfw` update even when the separate 64-kB asset partition is updated later.
Missing or modified required files still safely enter recovery. Interface
configuration is grouped under “Interfaces”; partitions, history and meter
interfaces remain unchanged. Feedback about different meters and local
integrations is welcome.

New USB installations use the `debugfs` label for optional 64-kB debug
storage. The same firmware automatically detects the previous `coredump` label
on existing OTA devices; OTA slots, offsets and history remain unchanged. A
USB reflash is therefore not required merely for the renamed label.

The universal firmware already contains W5500 Ethernet with Wi-Fi fallback.
The Ethernet/PoE board has not yet been validated on real hardware.

### License

Copyright © 2026 Michael Roßmann. Licensed under PolyForm Noncommercial 1.0.0. Private and other noncommercial use is permitted under the license; commercial use is not permitted. See the authoritative [license](LICENSE.md), [authorship notice](AUTHORS.md), [rights review](docs/legal/RIGHTS_REVIEW.md), and [trademark notice](docs/legal/TRADEMARKS.md).

---

<small>Hinweis / Note: Die LAN-Unterstützung wurde noch nicht an echter Hardware getestet. / Ethernet support has not yet been tested on real hardware.</small>
